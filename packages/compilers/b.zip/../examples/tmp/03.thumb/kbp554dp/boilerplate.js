/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./packages/examples/tmp/03.thumb/kbp554dp/src.js/suite.boilerplate.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/lodash/isArray.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isArray.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

module.exports = isArray;


/***/ }),

/***/ "./packages/examples/tmp/03.thumb/kbp554dp/src.js/index.source.jsx":
/*!*************************************************************************!*\
  !*** ./packages/examples/tmp/03.thumb/kbp554dp/src.js/index.source.jsx ***!
  \*************************************************************************/
/*! exports provided: Thumb */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Thumb", function() { return Thumb; });
/* harmony import */ var _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tsx-air/framework */ "./packages/framework/src/index.ts");


let Thumb = /** @class */ (() => {
    class Thumb extends _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["Component"] {
        constructor() {
            super(...arguments);
            this.lambda0 = (...args) => this._lambda0(...args);
            this.lambda1 = (...args) => this._lambda1(...args);
        }
        preRender() {
            const { props } = this;
            const { state } = this.state;
            ;
            Object(_tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["when"])(["props.url"], this.lambda0)
            return _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["VirtualElement"].fragment("1", Thumb.div1, this);
        }
        _lambda0() {
            const { state } = this.state;
            _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.update(this, Thumb.changesBitMap["state.imageLoaded"], () => state.imageLoaded = false)
        }
        _lambda1() {
            const { state } = this.state;
            _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.update(this, Thumb.changesBitMap["state.imageLoaded"], () => state.imageLoaded = true)
        }
    }
    Thumb.factory = new _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["CompFactory"](Thumb, { "props.url": 1 << 0, "props.onClick": 1 << 1, "state.imageLoaded": 1 << 2 }, props => ({
        "state": {
            imageLoaded: false
        }
    }));
    return Thumb;
})();

{
    let div0 = /** @class */ (() => {
        class div0 extends _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["Fragment"] {
            toString() {
                return this.unique(`<div class="preloader"></div>`);
            }
            hydrate(_, t) {
                this.ctx.root = t
            }
        }
        div0.factory = new _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["Factory"](div0, Thumb.changesBitMap);
        return div0;
    })();
    Thumb.div0 = div0
}
{
    let div1 = /** @class */ (() => {
        class div1 extends _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["Fragment"] {
            updateView($ch) {
                const { props } = this;
                const { state } = this.state;
                const $b = this.changesBitMap
                if ($ch & ($b["state.imageLoaded"]))
                    _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.updateExpression(this.ctx.expressions[0], state.imageLoaded ? null : _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["VirtualElement"].fragment("0", Thumb.div0, this))
                if ($ch & ($b["props.url"]))
                    this.ctx.elements[1].setAttribute("src", props.url)
                if ($ch & ($b["state.imageLoaded"]))
                    this.ctx.elements[1].setAttribute("style", _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.spreadStyle({ display: state.imageLoaded ? "block" : "none" }))
            }
            toString() {
                const { props } = this;
                const { state } = this.state;
                return this.unique(`<div class="thumb" x-da="!">
        <!--X-->${_tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.toString(state.imageLoaded ? null : _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["VirtualElement"].fragment("0", Thumb.div0, this))}<!--X-->
        <img src="${props.url}" style="${{ display: state.imageLoaded ? "block" : "none" }}" x-da="!"></img>
    </div>`);
            }
            hydrate(_, t) {
                const { props } = this;
                const { state } = this.state;
                this.hydrateExpressions([state.imageLoaded ? null : _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["VirtualElement"].fragment("0", Thumb.div0, this)], t)
                this.hydrateElements(t)
                this.ctx.elements[1].addEventListener("load", this.owner.lambda1)
                this.ctx.root = t
            }
        }
        div1.factory = new _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["Factory"](div1, Thumb.changesBitMap);
        return div1;
    })();
    Thumb.div1 = div1
}
//# sourceMappingURL=index.source.jsx.map

/***/ }),

/***/ "./packages/examples/tmp/03.thumb/kbp554dp/src.js/suite.boilerplate.js":
/*!*****************************************************************************!*\
  !*** ./packages/examples/tmp/03.thumb/kbp554dp/src.js/suite.boilerplate.js ***!
  \*****************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tsx-air/framework */ "./packages/framework/src/index.ts");
/* harmony import */ var _index_source__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.source */ "./packages/examples/tmp/03.thumb/kbp554dp/src.js/index.source.jsx");


const element = document.querySelector('div');
window.app = Object(_tsx_air_framework__WEBPACK_IMPORTED_MODULE_0__["render"])(_index_source__WEBPACK_IMPORTED_MODULE_1__["Thumb"], { url: '/images/pretty-boy.jpg' }, undefined, element, 'append');
//# sourceMappingURL=suite.boilerplate.js.map

/***/ }),

/***/ "./packages/framework/src/api/bind.ts":
/*!********************************************!*\
  !*** ./packages/framework/src/api/bind.ts ***!
  \********************************************/
/*! exports provided: bind */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bind", function() { return bind; });
const bind = {
    init: (value) => value,
    when: (_predicate, _action) => void (0),
    wasChanged: (_value) => () => true
};


/***/ }),

/***/ "./packages/framework/src/api/component.ts":
/*!*************************************************!*\
  !*** ./packages/framework/src/api/component.ts ***!
  \*************************************************/
/*! exports provided: ComponentApi, render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentApi", function() { return ComponentApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../types */ "./packages/framework/src/types/index.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./types */ "./packages/framework/src/api/types.ts");


class ComponentApi {
    constructor($instance) {
        this.$instance = $instance;
        this.updateProps = (props) => {
            _types__WEBPACK_IMPORTED_MODULE_1__["TSXAir"].runtime.update(this.$instance, -1, () => this.$instance.props = props);
        };
        this.setProp = (key, value) => _types__WEBPACK_IMPORTED_MODULE_1__["TSXAir"].runtime.update(this.$instance, this.$instance.changesBitMap[`props.${key}`], () => this.$instance.props[key] = value);
        this.getProp = (key) => this.$instance.props[key];
    }
}
function render(component, props, state, target, add = 'append') {
    var _a, _b;
    if (!_types__WEBPACK_IMPORTED_MODULE_0__["Component"].isType(component)) {
        throw new Error(`Invalid component: not compiled as TSXAir`);
    }
    const comp = _types__WEBPACK_IMPORTED_MODULE_1__["TSXAir"].runtime.render(_types__WEBPACK_IMPORTED_MODULE_0__["VirtualElement"].root(component, props, state));
    if (target) {
        const dom = comp.getDomRoot();
        switch (add) {
            case 'append':
                target.append(dom);
                break;
            case 'before':
                (_a = target.parentNode) === null || _a === void 0 ? void 0 : _a.insertBefore(dom, target);
                break;
            case 'replace':
                (_b = target.parentNode) === null || _b === void 0 ? void 0 : _b.insertBefore(dom, target);
                target.remove();
        }
    }
    return new ComponentApi(comp);
}


/***/ }),

/***/ "./packages/framework/src/api/delegate.ts":
/*!************************************************!*\
  !*** ./packages/framework/src/api/delegate.ts ***!
  \************************************************/
/*! exports provided: window, body, document */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "window", function() { return window; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "body", function() { return body; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "document", function() { return document; });
// @ts-ignore
const window = {};
// @ts-ignore
const body = {};
// @ts-ignore
const document = {};


/***/ }),

/***/ "./packages/framework/src/api/lifecycle.ts":
/*!*************************************************!*\
  !*** ./packages/framework/src/api/lifecycle.ts ***!
  \*************************************************/
/*! exports provided: when, always, requestRender */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "when", function() { return when; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "always", function() { return always; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "requestRender", function() { return requestRender; });
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./types */ "./packages/framework/src/api/types.ts");

function when(predicate, action) {
    _types__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.when(predicate, action);
}
const always = () => true;
async function requestRender() { }


/***/ }),

/***/ "./packages/framework/src/api/store.ts":
/*!*********************************************!*\
  !*** ./packages/framework/src/api/store.ts ***!
  \*********************************************/
/*! exports provided: store */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "store", function() { return store; });
const store = (initial) => initial;
store.derived = (val) => val;
store.async = (_p) => ({});


/***/ }),

/***/ "./packages/framework/src/api/types.ts":
/*!*********************************************!*\
  !*** ./packages/framework/src/api/types.ts ***!
  \*********************************************/
/*! exports provided: TSXAir */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TSXAir", function() { return TSXAir; });
/* harmony import */ var _runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../runtime */ "./packages/framework/src/runtime/index.ts");

const TSXAir = (t) => t;
// A silly hack to keep Nadav happy
TSXAir.runtime = _runtime__WEBPACK_IMPORTED_MODULE_0__["default"];


/***/ }),

/***/ "./packages/framework/src/index.ts":
/*!*****************************************!*\
  !*** ./packages/framework/src/index.ts ***!
  \*****************************************/
/*! exports provided: TSXAir, delegate, bind, store, when, always, requestRender, Component, Factory, CompFactory, Displayable, Fragment, VirtualElement, runtime, runtimeUtils, ComponentApi, render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _api_delegate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api/delegate */ "./packages/framework/src/api/delegate.ts");
/* harmony reexport (module object) */ __webpack_require__.d(__webpack_exports__, "delegate", function() { return _api_delegate__WEBPACK_IMPORTED_MODULE_0__; });
/* harmony import */ var _api_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api/types */ "./packages/framework/src/api/types.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TSXAir", function() { return _api_types__WEBPACK_IMPORTED_MODULE_1__["TSXAir"]; });

/* harmony import */ var _api_bind__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./api/bind */ "./packages/framework/src/api/bind.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "bind", function() { return _api_bind__WEBPACK_IMPORTED_MODULE_2__["bind"]; });

/* harmony import */ var _api_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api/store */ "./packages/framework/src/api/store.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "store", function() { return _api_store__WEBPACK_IMPORTED_MODULE_3__["store"]; });

/* harmony import */ var _api_lifecycle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api/lifecycle */ "./packages/framework/src/api/lifecycle.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "when", function() { return _api_lifecycle__WEBPACK_IMPORTED_MODULE_4__["when"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "always", function() { return _api_lifecycle__WEBPACK_IMPORTED_MODULE_4__["always"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "requestRender", function() { return _api_lifecycle__WEBPACK_IMPORTED_MODULE_4__["requestRender"]; });

/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./types */ "./packages/framework/src/types/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["Component"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Factory", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["Factory"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CompFactory", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["CompFactory"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Displayable", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["Displayable"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["Fragment"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "VirtualElement", function() { return _types__WEBPACK_IMPORTED_MODULE_5__["VirtualElement"]; });

/* harmony import */ var _runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./runtime */ "./packages/framework/src/runtime/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "runtime", function() { return _runtime__WEBPACK_IMPORTED_MODULE_6__["default"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "runtimeUtils", function() { return _runtime__WEBPACK_IMPORTED_MODULE_6__["utils"]; });

/* harmony import */ var _api_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./api/component */ "./packages/framework/src/api/component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ComponentApi", function() { return _api_component__WEBPACK_IMPORTED_MODULE_7__["ComponentApi"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _api_component__WEBPACK_IMPORTED_MODULE_7__["render"]; });













/***/ }),

/***/ "./packages/framework/src/runtime/index.ts":
/*!*************************************************!*\
  !*** ./packages/framework/src/runtime/index.ts ***!
  \*************************************************/
/*! exports provided: default, utils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./runtime */ "./packages/framework/src/runtime/runtime.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./packages/framework/src/runtime/utils.ts");
/* harmony reexport (module object) */ __webpack_require__.d(__webpack_exports__, "utils", function() { return _utils__WEBPACK_IMPORTED_MODULE_1__; });


/* harmony default export */ __webpack_exports__["default"] = (new _runtime__WEBPACK_IMPORTED_MODULE_0__["Runtime"]());



/***/ }),

/***/ "./packages/framework/src/runtime/runtime.helpers.ts":
/*!***********************************************************!*\
  !*** ./packages/framework/src/runtime/runtime.helpers.ts ***!
  \***********************************************************/
/*! exports provided: updateExpression, asDomNodes, asSingleDomNode, remapChangedBit */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateExpression", function() { return updateExpression; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "asDomNodes", function() { return asDomNodes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "asSingleDomNode", function() { return asSingleDomNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "remapChangedBit", function() { return remapChangedBit; });
/* harmony import */ var lodash_isArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash/isArray */ "./node_modules/lodash/isArray.js");
/* harmony import */ var lodash_isArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_isArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! .. */ "./packages/framework/src/index.ts");


function updateExpression(expMarkers, values) {
    var _a;
    let first;
    for (const v of values) {
        first = first || v;
        expMarkers[1].parentNode.insertBefore(v, expMarkers[1]);
    }
    // handle empty list
    first = first || expMarkers[1];
    while (expMarkers[0].nextSibling
        && expMarkers[0].nextSibling !== first) {
        (_a = expMarkers[0].nextSibling) === null || _a === void 0 ? void 0 : _a.remove();
    }
}
function* asDomNodes(values) {
    if (lodash_isArray__WEBPACK_IMPORTED_MODULE_0___default()(values)) {
        for (const v of values) {
            yield asSingleDomNode(v);
        }
    }
    else {
        if (values !== undefined) {
            yield asSingleDomNode(values);
        }
    }
}
function asSingleDomNode(value) {
    if (___WEBPACK_IMPORTED_MODULE_1__["VirtualElement"].is(value)) {
        value = ___WEBPACK_IMPORTED_MODULE_1__["TSXAir"].runtime.getUpdatedInstance(value);
    }
    if (___WEBPACK_IMPORTED_MODULE_1__["Displayable"].is(value)) {
        return value.getDomRoot();
    }
    return new (___WEBPACK_IMPORTED_MODULE_1__["TSXAir"].runtime.Text)(value);
}
function remapChangedBit(changes, mapping) {
    if (mapping) {
        let remapped = 0;
        for (const [ch, pr] of mapping) {
            if (changes & pr) {
                remapped |= ch;
            }
        }
        return remapped;
    }
    else {
        return changes;
    }
}


/***/ }),

/***/ "./packages/framework/src/runtime/runtime.ts":
/*!***************************************************!*\
  !*** ./packages/framework/src/runtime/runtime.ts ***!
  \***************************************************/
/*! exports provided: Runtime */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Runtime", function() { return Runtime; });
/* harmony import */ var _runtime_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./runtime.helpers */ "./packages/framework/src/runtime/runtime.helpers.ts");
/* harmony import */ var lodash_isArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/isArray */ "./node_modules/lodash/isArray.js");
/* harmony import */ var lodash_isArray__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_isArray__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! .. */ "./packages/framework/src/index.ts");



class Runtime {
    constructor(window = globalThis.window, requestAnimationFrame = globalThis.requestAnimationFrame) {
        var _a;
        this.window = window;
        this.requestAnimationFrame = requestAnimationFrame;
        this.$stats = [];
        this.pending = new Map();
        this.viewUpdatePending = false;
        this.maxDepthPerUpdate = 50;
        this.maxDepth = 100;
        this.hydrating = 0;
        this.keyCounter = 0 | 0;
        this.when = this.always;
        this.hydrate = this.renderOrHydrate;
        this.render = this.renderOrHydrate;
        this.updateView = (_) => {
            var _a;
            let depth = 0;
            do {
                depth++;
                const { pending } = this;
                this.pending = new Map();
                for (let [instance, changes] of pending) {
                    if (___WEBPACK_IMPORTED_MODULE_2__["Component"].is(instance)) {
                        this.when = (predicate, action) => {
                            if (predicate.some(p => changes & instance.changesBitMap[p])) {
                                action();
                            }
                        };
                        const preRender = instance.preRender();
                        this.when = this.always;
                        // handle prerender state changes 
                        changes |= this.removeChanges(instance);
                        preRender.changes = Object(_runtime_helpers__WEBPACK_IMPORTED_MODULE_0__["remapChangedBit"])(changes, preRender.changeBitMapping);
                        const nextRoot = this.getUpdatedInstance(preRender);
                        const root = instance.ctx.root;
                        if (root !== nextRoot) {
                            (_a = root.getDomRoot().parentNode) === null || _a === void 0 ? void 0 : _a.insertBefore(nextRoot.getDomRoot(), root.getDomRoot());
                            root.getDomRoot().remove();
                            instance.ctx.root = nextRoot;
                            // TODO: discuss pruning strategy 
                            instance.ctx.components[nextRoot.key] = nextRoot;
                        }
                    }
                    else {
                        instance.updateView(changes);
                    }
                }
            } while (this.pending.size && depth < this.maxDepthPerUpdate);
            this.viewUpdatePending = false;
            if (this.pending.size) {
                this.triggerViewUpdate();
            }
        };
        this.mockDom = (_a = window === null || window === void 0 ? void 0 : window.document) === null || _a === void 0 ? void 0 : _a.createElement('div');
        this.document = window === null || window === void 0 ? void 0 : window.document;
        this.HTMLElement = window === null || window === void 0 ? void 0 : window.HTMLElement;
        this.Text = window === null || window === void 0 ? void 0 : window.Text;
        if (requestAnimationFrame !== undefined) {
            this.requestAnimationFrame = requestAnimationFrame.bind(globalThis);
        }
    }
    update(instance, bits, mutator) {
        this.addChange(instance, bits);
        this.triggerViewUpdate();
        return mutator();
    }
    updateExpression(exp, value) {
        exp.value = value;
        Object(_runtime_helpers__WEBPACK_IMPORTED_MODULE_0__["updateExpression"])([exp.start, exp.end], Object(_runtime_helpers__WEBPACK_IMPORTED_MODULE_0__["asDomNodes"])(value));
    }
    toString(x) {
        if (lodash_isArray__WEBPACK_IMPORTED_MODULE_1___default()(x)) {
            return x.map(i => this.toString(i)).join('');
        }
        if (___WEBPACK_IMPORTED_MODULE_2__["VirtualElement"].is(x)) {
            return this.getUpdatedInstance(x).toString();
        }
        return (x === null || x === void 0 ? void 0 : x.toString()) || '';
    }
    getUpdatedInstance(vElm) {
        const { key, parent, owner } = vElm;
        if (!key || !owner || !parent) {
            throw new Error(`Invalid VirtualElement for getInstance: no key was assigned`);
        }
        if (key in parent.ctx.components) {
            const instance = parent.ctx.components[key];
            instance.props = vElm.props;
            this.addChange(instance, vElm.changes);
            return instance;
        }
        else {
            return this.render(vElm);
        }
    }
    getUniqueKey(prefix = '') {
        return `${prefix}${(this.keyCounter++).toString(36)}`;
    }
    always(_, action) {
        action();
    }
    spreadStyle(styleObj) {
        if (typeof styleObj === 'string') {
            return styleObj;
        }
        let style = '';
        for (const [key, val] of Object.entries(styleObj)) {
            style = style + `${key}=${val};`;
        }
        return style;
    }
    renderOrHydrate(vElm, dom) {
        const { key, props, state, type, parent } = vElm;
        if (___WEBPACK_IMPORTED_MODULE_2__["Component"].isType(type)) {
            const comp = this.hydrateComponent(key, parent, dom, type, props, state);
            if (vElm.parent && key) {
                vElm.parent.ctx.components[key] = comp;
            }
            return comp;
        }
        const instance = type.factory.newInstance(vElm.key, vElm);
        if (!dom) {
            this.mockDom.innerHTML = instance.toString();
            dom = this.mockDom.children[0];
        }
        instance.hydrate(vElm, dom);
        if (vElm.parent && key) {
            vElm.parent.ctx.components[key] = instance;
        }
        return instance;
    }
    hydrateExpression(value, start) {
        value = lodash_isArray__WEBPACK_IMPORTED_MODULE_1___default()(value) ? value : [value];
        let hydratedDomNode = start;
        const hydrated = value
            .filter((i) => i !== undefined && i !== null && i !== '')
            .map((i) => {
            hydratedDomNode = hydratedDomNode.nextSibling;
            if (___WEBPACK_IMPORTED_MODULE_2__["VirtualElement"].is(i)) {
                return this.hydrate(i, hydratedDomNode);
            }
            return i.toString();
        });
        if (!(hydratedDomNode.nextSibling instanceof
            //@ts-ignore
            this.window.Comment)) {
            throw new Error(`Hydration error: Expression does not match data. (no ending comment)`);
        }
        return {
            start,
            end: hydratedDomNode.nextSibling,
            value: hydrated
        };
    }
    hydrateComponent(key, parent, domNode, type, props, state) {
        this.hydrating++;
        const instance = (parent === null || parent === void 0 ? void 0 : parent.ctx.components[key]) || type.factory.newInstance(key, { props, state, parent });
        const preRender = instance.preRender();
        // prerender already expressed in view ny toString
        this.pending.delete(instance);
        instance.ctx.root = this.renderOrHydrate(preRender, domNode);
        this.hydrating--;
        return instance;
    }
    addChange(instance, change) {
        const currentChange = this.pending.get(instance) | change;
        this.pending.set(instance, currentChange);
    }
    removeChanges(instance) {
        const r = (this.pending.get(instance) | 0);
        this.pending.delete(instance);
        return r;
    }
    triggerViewUpdate() {
        if (!this.viewUpdatePending && !this.hydrating) {
            this.viewUpdatePending = true;
            this.requestAnimationFrame(this.updateView);
        }
    }
}


/***/ }),

/***/ "./packages/framework/src/runtime/utils.ts":
/*!*************************************************!*\
  !*** ./packages/framework/src/runtime/utils.ts ***!
  \*************************************************/
/*! exports provided: assignTextContent, noop, toStringChildren, spreadToElementString, updateSpreadElement, setProp, handleChanges, setStyle, createFromString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "assignTextContent", function() { return assignTextContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toStringChildren", function() { return toStringChildren; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spreadToElementString", function() { return spreadToElementString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSpreadElement", function() { return updateSpreadElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setProp", function() { return setProp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleChanges", function() { return handleChanges; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setStyle", function() { return setStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createFromString", function() { return createFromString; });
function assignTextContent(field, value) {
    return () => field.textContent = value;
}
const noop = (..._) => void (0);
function toStringChildren(props, factory) {
    return props.map(p => factory.toString(p)).join('');
}
const validKeys = (data) => Object.keys(data)
    // @ts-ignore
    .filter(prop => data[prop] && /^[a-z][\w$\-]*$/i.test(prop));
const convertClassName = (key) => key === 'className' ? 'class' : key;
function spreadToElementString(elmType, data) {
    const props = validKeys(data)
        // @ts-ignore
        .map(prop => `${convertClassName(prop)}="${data[prop]}"`).join(' ');
    // @ts-ignore
    return `<${elmType} ${props}>${data.$textContent || ''}</${elmType}>`;
}
function updateSpreadElement(elm, data) {
    const keys = new Set(validKeys(data));
    Array.from(elm.attributes).forEach(att => {
        if (keys.has(convertClassName(att.name))) {
            // @ts-ignore
            att.value = data[att.name];
            keys.delete(att.name);
        }
        else {
            elm.removeAttribute(convertClassName(att.name));
        }
    });
    // @ts-ignore
    keys.forEach(k => elm.setAttribute(convertClassName(k), data[k]));
    if ('$textContent' in data) {
        // @ts-ignore
        elm.textContent = data.$textContent;
    }
}
function setProp(instance, p, value, key) {
    if (p[key] !== value) {
        p[key] = value;
        // @ts-ignore
        return instance.constructor.changeBitmask['props.' + key];
    }
    return 0;
}
function handleChanges(changeMask, handlers, changesFlags) {
    for (const [key, action] of handlers) {
        if (changeMask[key] & changesFlags) {
            action();
        }
    }
}
function setStyle(element, style) {
    let stl = '';
    for (const [key, value] of Object.entries(style)) {
        stl = `${stl}${key}:${isNaN(Number(value)) ? value : (value | 0) + 'px'};`;
    }
    element.setAttribute('style', stl);
}
function createFromString(str) {
    const factory = document.createElement('div');
    factory.innerHTML = str;
    return factory.children[0];
}


/***/ }),

/***/ "./packages/framework/src/types/component.ts":
/*!***************************************************!*\
  !*** ./packages/framework/src/types/component.ts ***!
  \***************************************************/
/*! exports provided: Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return Component; });
/* harmony import */ var _api_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../api/types */ "./packages/framework/src/api/types.ts");
/* harmony import */ var _displayable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./displayable */ "./packages/framework/src/types/displayable.ts");


class Component extends _displayable__WEBPACK_IMPORTED_MODULE_1__["Displayable"] {
    constructor(key, parent, props, state, volatile = {}) {
        super(key, parent, props, state, volatile);
        this.key = key;
        this.props = props;
        this.state = state;
        let depth = 0;
        while (parent) {
            depth++;
            parent = parent === null || parent === void 0 ? void 0 : parent.owner;
        }
        if (depth > _api_types__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.maxDepth) {
            throw new Error(`Component tree too deep (over ${_api_types__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.maxDepth})
    This is a component recursion protection - change TSXAir.runtime.maxDepth (or fix your code)`);
        }
    }
    static is(x) {
        return x && x instanceof Component;
    }
    static isType(x) {
        return x && x.prototype instanceof Component;
    }
    toString() {
        return _api_types__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.toString(this.preRender());
    }
    preRender() { throw new Error(`not implemented`); }
    hydrate(preRendered, target) {
        this.ctx.root = _api_types__WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.hydrate(preRendered, target);
    }
}


/***/ }),

/***/ "./packages/framework/src/types/displayable.ts":
/*!*****************************************************!*\
  !*** ./packages/framework/src/types/displayable.ts ***!
  \*****************************************************/
/*! exports provided: Displayable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Displayable", function() { return Displayable; });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! .. */ "./packages/framework/src/index.ts");

class Displayable {
    constructor(key, parent, props, state, volatile) {
        this.key = key;
        this.props = props;
        this.state = state;
        this.volatile = volatile;
        this.ctx = {
            root: null,
            expressions: [],
            elements: [],
            components: {}
        };
        // requestAnimationFrame(() => this.$afterMount());
        this.innerKey = ___WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime.getUniqueKey();
        while (parent && !Displayable.is(parent)) {
            parent = parent.parent;
        }
        this.parent = parent;
    }
    static is(x) {
        return x && x instanceof Displayable;
    }
    afterMount(_ref) { }
    afterUnmount() { }
    get fullKey() {
        return this.parent ? `${this.parent.fullKey}${this.key}` : this.key;
    }
    get owner() {
        var _a;
        return ___WEBPACK_IMPORTED_MODULE_0__["Component"].is(this.parent) ? this.parent : (_a = this.parent) === null || _a === void 0 ? void 0 : _a.owner;
    }
    dispose() { }
    ;
    getDomRoot() {
        const { root } = this.ctx;
        if (Displayable.is(root)) {
            return root.getDomRoot();
        }
        const { HTMLElement, Text } = ___WEBPACK_IMPORTED_MODULE_0__["TSXAir"].runtime;
        if (root instanceof HTMLElement || root instanceof Text) {
            return root;
        }
        throw new Error(`Invalid Displayable: root is not a Displayable/HTMLElement`);
    }
    hydrate(_preRender, _target) { throw new Error(`not implemented`); }
    toString() { throw new Error(`not implemented`); }
}


/***/ }),

/***/ "./packages/framework/src/types/factory.ts":
/*!*************************************************!*\
  !*** ./packages/framework/src/types/factory.ts ***!
  \*************************************************/
/*! exports provided: Factory, CompFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Factory", function() { return Factory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompFactory", function() { return CompFactory; });
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./component */ "./packages/framework/src/types/component.ts");
/* harmony import */ var _fragment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fragment */ "./packages/framework/src/types/fragment.ts");


class Factory {
    constructor(type, changesBitMap) {
        this.type = type;
        this.changesBitMap = changesBitMap;
        type.changesBitMap = changesBitMap;
    }
    // creates an instance (with empty context)
    newInstance(key, parent) {
        if (_fragment__WEBPACK_IMPORTED_MODULE_1__["Fragment"].isType(this.type)) {
            // @ts-ignore
            return new this.type(key, parent);
        }
        throw new Error(`Invalid fragment`);
    }
}
class CompFactory extends Factory {
    constructor(type, changesBitMap, initialState = (_) => { }) {
        super(type, changesBitMap);
        this.type = type;
        this.changesBitMap = changesBitMap;
        this.initialState = initialState;
    }
    newInstance(key, data) {
        if (_component__WEBPACK_IMPORTED_MODULE_0__["Component"].isType(this.type)) {
            // @ts-ignore
            const instance = new this.type(key, data.parent, data.props || {}, data.state ||
                this.initialState(data.props), {});
            // @ts-ignore
            instance.changesBitMap = this.changesBitMap;
            return instance;
        }
        throw new Error(`Invalid component`);
    }
}


/***/ }),

/***/ "./packages/framework/src/types/fragment.ts":
/*!**************************************************!*\
  !*** ./packages/framework/src/types/fragment.ts ***!
  \**************************************************/
/*! exports provided: Fragment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return Fragment; });
/* harmony import */ var _displayable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./displayable */ "./packages/framework/src/types/displayable.ts");
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./component */ "./packages/framework/src/types/component.ts");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! .. */ "./packages/framework/src/index.ts");



class Fragment extends _displayable__WEBPACK_IMPORTED_MODULE_0__["Displayable"] {
    static is(x) {
        return x && x instanceof Fragment;
    }
    static isType(x) {
        return x.prototype instanceof Fragment;
    }
    constructor(key, parent) {
        let _owner = _component__WEBPACK_IMPORTED_MODULE_1__["Component"].is(parent) ? parent : parent.owner;
        if (!_owner) {
            throw new Error('Invalid fragment: no owner component');
        }
        super(key, parent, _owner.props, _owner.state, _owner.volatile);
        // @ts-ignore
        this.changesBitMap = _owner.changesBitMap;
    }
    updateView(_changes) { }
    hydrateExpressions(values, target) {
        return this.hydrateInternals(values, target, 'X', (v, t) => this.ctx.expressions.push(___WEBPACK_IMPORTED_MODULE_2__["TSXAir"].runtime.hydrateExpression(v, t)));
    }
    hydrateComponents(virtualComps, target) {
        this.hydrateInternals(virtualComps, target, 'C', (c, t) => ___WEBPACK_IMPORTED_MODULE_2__["TSXAir"].runtime.hydrate(c, t.nextElementSibling));
    }
    hydrateElements(target) {
        var _a;
        (_a = target.parentNode) === null || _a === void 0 ? void 0 : _a.querySelectorAll(`[x-da="${this.fullKey}"]`).forEach(e => this.ctx.elements.push(e));
    }
    hydrateInternals(values, target, type, hydrateFunc) {
        let expressionIndex = 0;
        let inExpressionString = false;
        const { document, window } = ___WEBPACK_IMPORTED_MODULE_2__["TSXAir"].runtime;
        // @ts-ignore
        const { NodeFilter } = window;
        const comments = document.createNodeIterator(target, NodeFilter.SHOW_COMMENT, {
            acceptNode: (node) => {
                if (inExpressionString) {
                    if (`<!--${node.textContent}-->` === this.comment(expressionIndex, type)) {
                        expressionIndex++;
                        inExpressionString = false;
                        return NodeFilter.FILTER_REJECT;
                    }
                    else {
                        return NodeFilter.FILTER_SKIP;
                    }
                }
                else {
                    if (`<!--${node.textContent}-->` === this.comment(expressionIndex, type)) {
                        inExpressionString = true;
                        return NodeFilter.FILTER_ACCEPT;
                    }
                    else {
                        return NodeFilter.FILTER_REJECT;
                    }
                }
            }
        });
        values.forEach(v => hydrateFunc(v, comments.nextNode()));
    }
    comment(index, type) {
        return `<!--${this.fullKey}${type}${index}-->`;
    }
    attribute(_) {
        return `x-da="${this.fullKey}"`;
    }
    unique(str) {
        return this.withUniq(this.withUniq(str, '<!--X-->', (i) => this.comment(i, 'X')), '<!--C-->', (i) => this.comment(i, 'C'))
            .replace(/x-da="!"/g, `x-da="${this.fullKey}"`);
    }
    withUniq(str, placeholder, replace, withTrailing = true) {
        const src = str.split(placeholder);
        const res = [];
        let expCount = 0;
        let skipNext = true;
        for (const chunk of src) {
            if (!skipNext) {
                const comment = replace(expCount++);
                res.push(comment);
                res.push(chunk);
                withTrailing && res.push(comment);
            }
            else {
                res.push(chunk);
            }
            skipNext = !skipNext;
        }
        return res.join('');
    }
}


/***/ }),

/***/ "./packages/framework/src/types/index.ts":
/*!***********************************************!*\
  !*** ./packages/framework/src/types/index.ts ***!
  \***********************************************/
/*! exports provided: Component, Factory, CompFactory, Displayable, Fragment, VirtualElement */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./component */ "./packages/framework/src/types/component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return _component__WEBPACK_IMPORTED_MODULE_0__["Component"]; });

/* harmony import */ var _factory__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./factory */ "./packages/framework/src/types/factory.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Factory", function() { return _factory__WEBPACK_IMPORTED_MODULE_1__["Factory"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CompFactory", function() { return _factory__WEBPACK_IMPORTED_MODULE_1__["CompFactory"]; });

/* harmony import */ var _displayable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./displayable */ "./packages/framework/src/types/displayable.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Displayable", function() { return _displayable__WEBPACK_IMPORTED_MODULE_2__["Displayable"]; });

/* harmony import */ var _fragment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fragment */ "./packages/framework/src/types/fragment.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return _fragment__WEBPACK_IMPORTED_MODULE_3__["Fragment"]; });

/* harmony import */ var _virtual_element__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./virtual.element */ "./packages/framework/src/types/virtual.element.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "VirtualElement", function() { return _virtual_element__WEBPACK_IMPORTED_MODULE_4__["VirtualElement"]; });








/***/ }),

/***/ "./packages/framework/src/types/virtual.element.ts":
/*!*********************************************************!*\
  !*** ./packages/framework/src/types/virtual.element.ts ***!
  \*********************************************************/
/*! exports provided: VirtualElement */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtualElement", function() { return VirtualElement; });
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./component */ "./packages/framework/src/types/component.ts");
/* harmony import */ var _runtime_runtime_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../runtime/runtime.helpers */ "./packages/framework/src/runtime/runtime.helpers.ts");


class VirtualElement {
    constructor(type, props, state, volatile, parent, key, changeBitMapping, changes = 0) {
        this.type = type;
        this.props = props;
        this.state = state;
        this.volatile = volatile;
        this.parent = parent;
        this.key = key;
        this.changeBitMapping = changeBitMapping;
        this.changes = changes;
    }
    static component(key, type, parent, changeBitMapping, props = {}, state, volatile) {
        return new VirtualElement(type, props, state, volatile, parent, key, changeBitMapping);
    }
    static root(type, props, state) {
        return new VirtualElement(type, props, state, undefined, undefined, '$');
    }
    static fragment(key, type, parent) {
        return new VirtualElement(type, parent.props, parent.state, parent.volatile, parent, key);
    }
    static is(x) {
        return x && x instanceof VirtualElement;
    }
    withKey(key) {
        const { type, parent, props, volatile, state, changes, changeBitMapping: changeBitRemapping } = this;
        return new VirtualElement(type, props, state, volatile, parent, key, changeBitRemapping, changes);
    }
    ;
    withChanges(changes) {
        const { type, parent, props, volatile, state, key, changeBitMapping: changeBitRemapping } = this;
        return new VirtualElement(type, props, state, volatile, parent, key, changeBitRemapping, Object(_runtime_runtime_helpers__WEBPACK_IMPORTED_MODULE_1__["remapChangedBit"])(changes, changeBitRemapping));
    }
    ;
    get fullKey() {
        return this.parent ? `${this.parent.fullKey}${this.key}` : this.key || 'NO KEY';
    }
    get owner() {
        var _a;
        return _component__WEBPACK_IMPORTED_MODULE_0__["Component"].is(this.parent) ? this.parent : (_a = this.parent) === null || _a === void 0 ? void 0 : _a.owner;
    }
    toString() {
        var _a;
        return `[VirtualElement<${this.type.name}> (key:"${this.key}", parent:${(_a = this.parent) === null || _a === void 0 ? void 0 : _a.fullKey})]`;
    }
}


/***/ })

/******/ });
//# sourceMappingURL=boilerplate.js.map